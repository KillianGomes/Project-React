import React, { Fragment } from 'react';
const Accueil = () => {
    let tabVoitures = JSON.parse(localStorage.getItem('datas'));
    console.log(tabVoitures);
    return (
        <Fragment> 
        <div className="jumbotron jumbotron-fluid">
            <div className="container">
                <h1 className="display-4 text-center">Concessionnaire</h1>
                <p className="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
            </div>
        </div>
        {tabVoitures.map((voiture, index) =>{
         return( 
            <div className="row">
            <div className="col-sm-6">
                <div className="card card border-primary ">
                <img src="" alt="" />
                <div className="card-body">
                    <h5 className="card-title">Special title treatment</h5>
                    <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="#" className="btn btn-primary">Go somewhere</a>
                </div>
                </div>
            </div>
            <div className="col-sm-6">
                <div className="card">
                <img src="" alt="" />
                <div className="card-body card border-primary ">
                    <h5 className="card-title">Special title treatment</h5>
                    <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="#" className="btn btn-primary">Go somewhere</a>
                </div>
                </div>
            </div>
            </div>
         )
        })
      }
        </Fragment>
     );
}
 
export default Accueil;