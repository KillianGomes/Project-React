import React from 'react';
const Page404 = () => {
    return ( 
        <h1>Page not found</h1>
     );
}
 
export default Page404;