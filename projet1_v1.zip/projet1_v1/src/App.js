import React from 'react';
import Menu from './components/Menu';


function App() {
  return (
    <div className="container">
      <Menu /> 
    </div>
  );
}

export default App;
